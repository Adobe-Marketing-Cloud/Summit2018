
(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Explosion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BF1853").s().p("AAQCJIgDgCIgDgDQAAgbgKgYIgbg7QgKgXABgcIABg0QAAgYABgZIADgDIAEgBIAFgCIAAgBIAGADIAEABQAGAagBAcIgDA8QgBAeARAaQASAYAJAdQAJAagOAVIgGABIgGgBg");
	this.shape.setTransform(1.8,303.4,1,1,-1.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BF1853").s().p("AgJGvQioAAiigqQhdgYhRg1QhmhChGhiQgGggAFggQAUh1CGAZQCJAZBsBhQAfAcAqARQB7AxB3g5QAMgFAIgNQA7hagMhrQgGgtgigcIgBgEQgCgJAAgKIABgdIgCgqQgDgdAPgXQAZgnAlgcQAugkAxgfQANgIAMgDQEWgYCEDvQBQCRhtCDQhdBxiABLQhTAxhWAuQhOAqhSAdQgnAOgqAAIgEAAg");
	this.shape_1.setTransform(-6.8,316.5,1,1,-1.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BF1853").s().p("AlQOKQAlhTAdhYQAZhNgChTQgDhcgLhZQgWiyhWihQhji5hfi8QhOicATiyQAFguAUgqIgBgEIgDgEIgDgFIgCgEIAAgEQAAgIAFgIQAMgOANgNIAagYIAfgdIAcgdQAMgMAOgIIAIgFQCBA8B+BLQAeASAmgLQCvgyC2AGQAbABAcANQFVCcAHFsQAHFYi7EfQhrCkimBxQiHBciLBWQg5Ajg2AnQgrAfgsAAQgSAAgTgGg");
	this.shape_2.setTransform(26.3,267.8,1,1,-1.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#BF1853").s().p("AATOgQgwhOgNhiQgEgegXgZQhlhrh9hSQhbg8hWg/QjFiQhZjoQhgj7A+kJQAZhqBLhPQCXifDHhTIAWABQAFAAAEACIAGAEQgLB3A7BXQAGAJANADQCgAoCggvQEbhTEEBzQAoASAdAjQCJCngPDeQgJCJgXCEQgvEUicDpIg7BWQg1Awg5AsQhGA3g/BAQgYAZgfARIgFAEQg0Ang/ANQgSAEgSAAQgZAAgYgHg");
	this.shape_3.setTransform(17.7,233.9,1,1,-1.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BF1853").s().p("AqLR4QichEiBhuQkcjzgTl5QgIiogBipQgBjDBQi4QAmhZAjhcQCmnCHIiyQCZg7CfgeQHcgWGEEPQBwBOBTBrQEhF0A3HPQA6HqlqFcQhFBChDBGQiMCSjFBBQhnAhhpAVQieAfiXAAQk1AAkhh/g");
	this.shape_4.setTransform(17.4,192.6,1,1,-1.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BF1853").s().p("AjyExQhJhPAEhxQAGiGAnh+QAniABIhwQARgIAMgOQAagcAmgNQAmgNAngEIAXgDQBkA2A2BsQAyBlAoBpQAeBPAABXQAAB0gZBuQgZBshUBIIgpABQjfAAicimg");
	this.shape_5.setTransform(139.6,54.8,1,1,-1.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BF1853").s().p("AgzBTQgvgdgBgzIAAgsQAAgUgDgTQgEgmAggIIALAEIAHAFQAFAGABAIIABAZIAAAaIAAAZIAAAYIAAAPQAIAOAOALQAfAYAqAGQAoAGASAeIgBAGIgBAEIgDAGIgEAFIgFADQhKgChDgqg");
	this.shape_6.setTransform(122.1,79.6,1,1,-1.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BF1853").s().p("AgtBEQgagwAGg5QAGg6A4gFQBEANACBGQACA6gmAnQgUAVgRAAQgWAAgRghg");
	this.shape_7.setTransform(40.1,-203.4,1,1,-1.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BF1853").s().p("AggHdQhUgdhDhDQgfgggwgCQhlgGBDg7QATgQAcAEQCOAVBkBnQAMANAYAAQA2gBA2gDQBXhpARiEQAZjEhEi1Qg+ilifgWQghgEgeAXQhdBHgfBuQgWBNgnhCQgMgUAGgbQAYhrBShMQA8g3BKgYQDVAbBUDPQBdDmgqD5QgNBRglBKQg/B9h7AAQgxAAg6gUg");
	this.shape_8.setTransform(139.8,54.1,1,1,-1.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#BF1853").s().p("AgLM3QhCgfAIhcQAOi3AEi2QAIlugFlvQgDjiBIjCQACgFAGgCQA/A/gfByQgLArgCAuQgQFrAAFtQABFFgcFBQgBALgHAAQgDAAgFgDg");
	this.shape_9.setTransform(111.4,6.5,1,1,-1.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BF1853").s().p("AinJwQhMgpgnhQQhkjNB7iyQBjiOAoijQAriygSi6QgIhVA7ggQA4AagJBIQgGA7AAA9IAAB4QAAA9gCA8QgBAqAHAoQCdBqB5CKQAqAxAFBBQAOC/h8CXQgzA9hHASQgyANgvAAQhWAAhOgrg");
	this.shape_10.setTransform(95,-132,1,1,-1.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BF1853").s().p("AANF6Qg9gcAIhTQAQitgWioQgUigA2iIQADgHAIgBQA6A2gNBrQgQCAAQB9QAWCtgnCjQgBAHgGAAIgHgBg");
	this.shape_11.setTransform(43.1,-104.8,1,1,-1.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BF1853").s().p("Aj2KMQgujNAjjSQAIgwAlghQBQhGAfhcQAwiOACiZQhHgag6gvQgygpgTg9QgXhHgFhNQgGhUAxhDQApg4A8gSQASAAARAEQARADAPALQAOAKAOAJQATALANASQAKARAIASQADAIAHAFQBfAIARBXQANBEACBFQACBbgBBcQAABfgDBdQgDBeAABeIAAAYQB0BWAOCQQAEAnAAAoQABDKhrCnQg0BShnAJIgeABQi8AAgtjGg");
	this.shape_12.setTransform(-10.5,-99,1,1,-1.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BF1853").s().p("AgNHJQgqg/AEhXQAKjSgIjQQgIizAkiiQACgKAMAAQA9AvgIBiQgEAzgBA3QgDDSANDQQAJCTg9BpQgCAEgDAAQgDAAgEgGg");
	this.shape_13.setTransform(-128.7,-71.3,1,1,-1.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BF1853").s().p("ABVFPQhnAShqgSQglgGgYgfQhKhdgKh2QgJhtAIhwQAKiaCigvQAVgGATgCQBtgOBeAyQBlA1ATBxQASBqgRBtQgRBpgpBkQgcBEgxAAQgVAAgZgMg");
	this.shape_14.setTransform(-85.7,-74.5,1,1,-1.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BF1853").s().p("AAYJ1Qg2gtAFhXQAEhFgEhGQgNkZgQkWQgMjYAhjLQACgNAOAAQA/A7gIBwQgVEbAdEXQAbELggECQgBAJgGAAQgEAAgGgFg");
	this.shape_15.setTransform(-61.6,10.6,1,1,-1.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BF1853").s().p("AggCrQgUgeAAgoQgBhmABhkQAAhRA9geQA/A4gZBqQgWBhABBmQABBAgSAAQgOAAgbgqg");
	this.shape_16.setTransform(-7,33.5,1,1,-1.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BF1853").s().p("AgbC5QgPgTABgbQABhlgJhkQgHhNAgg8QAGgMAMAAQBDBAgLB0IgVDIQgEArgSAAQgMAAgWgbg");
	this.shape_17.setTransform(0.7,19.7,1,1,-1.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#BF1853").s().p("AgMFRQgrg+AFhXQAJidgKibQgHh5AwhbQADgGAGgCQA9AwgIBiQgOCcAJCcQAIB/g0BhQgDAHgDAAQgFAAgEgIg");
	this.shape_18.setTransform(71,19.2,1,1,-1.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BF1853").s().p("AomYRQlChdjWkEQkLlGh7mJQgOgvAAgzQAGneDkmfQAPgcgKgiQh/myDxl2QASgdAkgEQEhghBcEKQARAwAgAmQAsABAtgLQCZgnBmhuQBJhOA1heQAlhBA4g0QA7g3BIgbQAFgDAGgBQFDACAeFCQAIBZBVAMQH3BHDsHFQC+FtAzGNQBOJmmaHCQleF/n5BMQiZAXiVAAQkSAAkJhMg");
	this.shape_19.setTransform(15.7,185,1,1,-1.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BF1853").s().p("AkkJNQhPg/hEhKQjoj9BClhQBSm4G3hfQH2AGClHLQAiBfADBnQARHmncDAQhfAmhXAAQiQAAh/hlg");
	this.shape_20.setTransform(91,-145.4,1,1,-1.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BF1853").s().p("ADZUWQgagNgJgcIgRgIQhbgxhQg/QhKg6gnhSQghhGgDhOQgEhTAAhTIAAhMQjuAZjjhhQiIg7hvhuQjkjiADlFQABiaBFh+QD7nNIYBHQAxAGApgHIgBgWQgEhGAWg/QAihdBMhDQCNh9C8gYQBcgLBYgGQDJgkB/CWQB7CQAuC4QAuC+huCiQhoCZirBWQh9BAh2ATIADAIQAGAWAEAXIAKA1QAGAegBAfQgBAeACAdQACAjgLAiQgNApgZAiQEvg+DYDSQDHDBgFEUQgCCZhFB0QiLDnkeAkQg1AHg1ANQg6APg2AAQhYAAhOgng");
	this.shape_21.setTransform(-58.4,-121,1,1,-1.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BF1853").s().p("ArQf4Qn+iCkHnIQj1mpAVn5QAHiiBEiTQhmhihahvQiijIAMkIQAHisA5iaQCPmEGxhTQExg6D3ChIBnBDQAJgJAEgLQAWhAA1gsQBHg8BYgiQDchWDlBBQA/ASA7AdQAKgtAYgjQAshCAmhGQBAh2BehiQCUiaC7hpQC3hoDLgQQFAgMD5DTQC2CbBEDrQArCUAACgQABFBjnDvQhYBbhnBHQiuB5jZAHIjOAGQFKF0gDH4QgBEZg9EKQgZBqg6BgQjsGHmbDCIh/A9QlLCilgAAQjLAAjSg2g");
	this.shape_22.setTransform(40.2,142.3,1,1,-1.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BF1853").s().p("AFSNvQmjgEmigcQiNgKh/hOQl9jtiDmIQgOgrAAgvQhvg9iRgbQiVgciWgfQi1gmirg9Qi1hAg1inQgehdAqhXQAKgWAGgYQBeg3BlgwQAggPAkgKQAwgNAwgLQBMgSBOgPQBlgVBngIIAAgBQATAAASACQAMABAKAFQAHADAFAGQAGAIAFAKIADAJIgBAJQAAAFgDAFIgFAKIgHAIIgJAHQhsAPhrAUQg/AMhAAKQg3AIg1AOQg7APg1AcQg/AihCAcIgDAKIgHATQgGATgKASQgKASADAVIABATIABAJQADAQAIANIAEAJIAMAdIAHATQBnA1BnAwQBEAfBLALQBvAQBqAiQBtAjBvAaQB5AcB1AWIAAgJIAAgKIAAgTIABgTQACgJADgKQADgJACgKIABgTIABgJIADgKIAGgJIAJgKIAKgJIAKgHIAGgDQDgCQEOBDQKqCoKfivQC4gwCphSQDChfDLgnQAHAEAEAHQAHAIADAKQAHASgBATIgBAdIAAAcIgBAKIgGATIgDAJIgDAKIgGATQCSAXCqg8QA1gTAzgVQBsgrBxgiQBMgXBOgQQAegmABgwQAAgigHggQgJgogggUQg+gog5grQhjhJhzguQgTgIgOgQQgYgBgYgEQgLgBgKgFQgHgDgFgGQgIgIgFgLQgBgEAAgEIAAgKIADgJQABgFADgEQAEgGAFgEIAJgHQJhhTB5IOQAoCxibBmQj3ChkxAgQoEA1jmHMQhTCmi1A/QjIBFjVAAIgMAAg");
	this.shape_23.setTransform(11.7,250.6,1,1,-1.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BF1853").s().p("EgLZAl+QjcgoijidQirilhPjaQg4iZing0QiOgthshkQhmhghYhsQgvg7hIgdIiSg7IgKgKQhuhlgaiTQgVh0AxhoQANgdAUgWQA8hBBVgRQC1gkCLh1QA9g0BJgkQDfhuEGAlQCtAZCygHIgKgJQhQhRhZhHQjJifjjiAQgVgMgSgPIgLgHQgngbgYgpIgVglQgthQAKhcIADgdQAYicCKhaQA3gjA6gdIgJgDQjBg+iIiVQhghqAOiMQACgTAFgSQAJgiAGgiQAThmA/hTIAhgpQBxiICzgnQEDg4EBAsQAbAFAcgHIAAgJIAAgKIAAgJIAAgKIAAgJIAAgKIAAgJIAAgKQgBgEgDgEIgIgLQgFgEgEgGQgDgEgBgFIAAgJIAAg5IAAhWQAAg5AEg5QAGheBMg4QAsghA4gbIAQgJQA7gnBBgYIAKgDIAQgDQD9AAD+AEQB7ACBmBEQBqBIBABwQAwBWA4BKQABABAAABQAAAAABAAQAAABABAAQAAAAAAAAQEAgLEAAeQCVASCTAaQB+AWAUCAIADADQEHgyDHCJQA1AlAWBFQAlBxgJB6IAAAJIAABDIAAAcIAAC1IAAAJQAJB0hRBSQgkAjggArIAAAKIABBCQAAAzgTAuQgiBOhOAnQiKBGiVAtQgkALgkAQQgLAFgJAIQgeAagPAkIAAAJIADAKIADAKIADAJIAEAJIAGAKIAGAJIAKAKQAHADAIAAQE2gaEuA1QBIANA3A0QAaAZAYAdQAFAFAFAAQA5AIA5AFQALABALADIANAKQAuAlAeAuQAvBIAIBSQAIBaAABaIAAAwIAAAJIAABDIgBAJQgTBKgxBAQgjAvg8AQIgNADQhFAJhDAPIgCAKQgDAdgYATQghAagPAlQgZA4gtAvQhBBEhUAnQheAthTA0IAAAKIABAcQAAAPgCAOQgCATgEASQgJAkgRAgQgZAugsAgQg9AqhDAgIgkASQDoCMgMEFQgLDdivCDQkgDWllAxQlMAulLAAQmnAAmnhLg");
	this.shape_24.setTransform(-2.3,-11.2,1,1,-1.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#BF1853").s().p("EgMLAnfQhhgkg+hfQgFgHgGgFQg/gqgfhDIgFgLQgahagQhaQgJg0AAg2QlahblahSQhMgShLgjQi2hXiiiCIgTgOQhVhBgXhlQhSlkEOjRQCxiJDChvQDviJEGASQgCgGgEgFIgKgNIgJgLIgOgNIgMgMIgJgLIgDgMIgBgMIAAgMIgDgYIgGgjIgCgNIgCgLIgBgMIgCgYIAAgMQACgGAEgFQAEgHAGgGIAMgMIANgLIAegZIAdgXQACgGgCgCQg4g1gxg7QgkguAFg8QAFguAAgwQAAgeADgeQAFgqAIgqQAJgqANgpIADgLQAJgmAQgjQAHgRAGgSIAFgLIAHgMQlsBakXjYQiAhjAci0IABgMQAAhBgGhBQgUjjCgibQGEl1H2g3IgFgMIgHgMIgEgMIgEgMQgCgMgBgMIgBgXIAAgMIAAgMIAAgMIAAgMQACgFAEgFQAQgUASgRQAigjAxgHQBPgMBPgKIADgMIABgMIAAgMIAAgMIAAgMIAAgXIAAgMQACgGAEgFQAfgkAeglQAYggAggVQAzghA1ggQBBgoBNgFIAYgDQBvAABvADQAOABAOAEQA2A1A0AuQCKB8CzAsIE8BPQFBBQFTAOQAQAAAQAFIAgAJQA3AOAQAwQACADACAAQEHgNEEA1QAJADAIAFIAHAMQAFAMABAMQADASAAARIAAAkIAAAYIAAAYIAAAYIAAAjIAAAMQAjAwA1AiQB5BOA3CEQAgBNADBUQACAvgCAwQAAAGgCAGQgTA4gdAyIgIAMQiFCljXADQiyAChwBJIABALQAJBIBIAjQBEAhAwA5QAlAsACA5QABAeAAAeIAABHIAABTIAAAYIAAAMIAAA7QACAGAEAEQAzA2BBAGQDbAUDIBQQBKAfA3A5IAIALQAHApAAAqQAABygdBqQgXBSgjBRQgRAogPApQgDAHgFAEQgwAugUA+QgCAHgEAFQhSBthfBgQiuCyjtAlQgrAHgMAaIAEAMIAEAMIAFALIAGANQADAFAEAEIAhAcQAFAEAEAGQAEAGACAGQAIAXgBAZQgBAdABAeQABAZgIAWQgKAegPAdQgQAhgaAaQgVATgSAVQgOARgSAPIgPANQgGAGABAFQANBFgEBLQgEBHgJBGQgFArgQAlQgdBDgsA8QgQAVgLAYIgGALQgiA6gwAxIgMANQg4A8g/A0IhPBCIgcAIQizAyh2h3QgkglgqgeQgygkghg0QgNgVgVgNQgGgEgHgCQjPg+iNB1Ig8AyIgbAYQgOAEgOABQhAADg+gDQgOgBgOgEIgPgMIgNgMIgXgYIglgiQgPgNgQgMIgMgIQgYACgWAGQgFACgEAGQgIAXgKAYQg2B/h+A9QhWAphZAAQhLAAhNgdg");
	this.shape_25.setTransform(8.1,-44.3,1,1,-1.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BF1853").s().p("As7IeIgCgIIgBgIIABgHIACgIIACgIQCJg1CbgVQDQgdDOghQD2gnDyg5QDag0CHigQA5hEgNhlQgDgTAAgTQgXgrgegnQgigsgwgVQhXglhhgSQhcgRhXgVQi8gti5grQghgHACghIACgHIADgHQADgFAFgDIAHgFIAFgCIAMgCIABgCQExBLE6A+QGABMhXGEQgZBqhlAwQkqCMlIBFQlDBDlIA4QhHAMhAAAQg2AAgygIg");
	this.shape_26.setTransform(193.3,208.4,1,1,-1.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BF1853").s().p("AjrGJQlah3lEihQgjgSgGguQgslRFZhOQCIgeCDgzQCHgzCPgWIEQgrIABgBQAjAAAjACQAJABAIAEQAJAGAGAJQAEAGADAIIgBAHIgCAIIgFAIIgGAHIgHAFQlvAkldBoQj6BKiSCxQgbAgAHAzQAZC8DjAgQDNAcDABLQB2AuB1AgQFgBeFtgUQCLgIBTBOIgBAIIgCAHIgFAIIgGAHIgHAGQhFADhGAAQoQAAnzisg");
	this.shape_27.setTransform(-170.2,214,1,1,-1.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#BF1853").s().p("AnQKfQk9hWgykkQgLg+A/glQASgKAMgRQgCgDgEgCQgdgQgZgWQghgcgBgrQAAgrAWghQAegwA0gaQAwgYAsgeQAAgEgCgCQgGgGgHgEQgIgDgHgFIgIgHIgIgHIgHgIQgFhAAIhBQARiDBRhmQDfkXEjDKQCLBhCUiIQA4gzBHgOQENgGCTD3QAbAuAWAvQB2D/ihDzQgUAeAJApQAiCUgyCJQghBdhYBBQiIBkioAVQh6AOh5AAQkHAAkBhGg");
	this.shape_28.setTransform(23.6,272,1,1,-1.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#BF1853").s().p("EgMYAiVQg5gLgcgzIgGgBQivgEihgzQgsgOgmgeQgvglggguQgEgGgFgEQgGgFgHgEQgngVgsgQQhJgagzg9IgSgUIgKgKIgCgJIgBgdIAAgcQAAgKgCgJQgBgFgDgFIgEgJIgIgUQgEgJgCgKIgCgTQgBgJgDgJIgHgUIgFgTIgCgKQgsglg7AGQj9AYjMiBQg9gmgShDQgHgdgJgcQgXhLAHhPQAKh9BYhXQCIiFCqhOQB/g5CLgdQCDgbBsg9IAGgJQACgFAAgFQACgOAAgOIAAgKIAAgJIAAgKIAAgJIAAgKIgBgJQgBgFgCgFIgFgKIgEgJQhUgOhXAYQjzBEj3giIhXgLQh7gMgih2QgehtgfhpQgYhRhFg7QiGhyAfioQAii3DKhSQAUgIAQgXIgHgJIgIgLQgGgJgDgKIgDgIIgEgLIgEgJQiLgnh6hPQhVg3ADhhQAFiVBNiAQCjkTFFhGQDLgsCgiRQB+hyCogBQCpAACWhCQDThcDIhrQBDgkBDgTQEngQEYBUQCNArCTAJQEiATEegOQFDgPDRDVQBSBTB8AAQBeAAAxBYQBBB1BRBoQAFADAEAAQBwgGBbA1QAaAPAYATQAdAYAHAkQAEAXAAAYIAAATIAAAJIAAAnIAAAmIAABCIAAAKIgDATIgHAKQgMARgTAMIgaASIgfATIghATIgSALQgFAEgFAFQgDAEABABQAlAsA1ARQAxAQA2ALQAvAJAkAdQAdAXATAeIAMATIAHAJQAMARgCAWQgCAVALASQARAgAKAiIABAJQADADAEABQCBAdBvBDQA+AmAcBCQACAEAAAFQAHA9ABA/QABAtgHAqQgUB8h2A6QhdAthpAPQi0AaiYBAIABAJIAJAmQAEAPAGAOQADAKAGAIIAIALIAKATIAHASIAHAUQAEARAOALIAZAUIAKAJIADAKQALAqAFAsQADAcABAdQABAngLAlQgEAJgCAKIgCAJQgIAdgOAaQgWAqgJAvQgBAJgDAJQgSAygfAqQgzBChEAzQgvAjg0AcQgKAFgIAKQgDAFgBAFQgIAqACArIABAwQgBAmgCAmQgBAQgIANIgFAJQgLAbgVAUQglAlgeAqQgLAOgOAMQguAogxAlQg/Aug9AoQgKAGgJANQACAFADAEQAPATAYAMIAhARIAjATIAlAUIAQAJIANAJQAQA9gFBAQgHBVg/A+QiBB+ilA5Qi0A+jBgWQl4gsmDAnIixASQh6AMh5AAQj7AAjzgzg");
	this.shape_29.setTransform(10,-80.5,1,1,-1.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#BF1853").s().p("AlSEeIgMgKIgTgTQgPgOgMgQQgFgIgEgJIgFgKIgHgTIgKgdIgDgJQgBgFgDAAQg7gPg9gDQgtgCgkgbQgXgTgUgVIgCgKIgBgTIAAgbIAAgUIAAgJIAAgTIAAgdIAAgcQAsgtA3gXQCrhJC+ARQDCARC+gyQAxgNAsgFQAmAAAmAEQAlAEAlAHQApAJATAhQAVAjgHApQgGAmAUAdIAHAFQAPAJATADQAcAEAVAUQAKAKANAGQAOAHAQAFQASAGARAIQAWBHgYBMQg7C8juhWQjjhSjUBOQh3AriFAAIgUAAg");
	this.shape_30.setTransform(55.2,199.5,1,1,-1.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#BF1853").s().p("ADbLQQqCg6qJgSQrbgTrNhdQmXg1kBkRQhihpAJiQQAGhXAMhVQAthKBIg3QA2gpA+gXQC7hDDDgyQB9ghCBgOQDXgZDSg2QCvgsCogzQBZAABZACQAcAAAMAYQAEAJADAKIAAAJIgDAKIgGAKIgHAIIgJAHQtDBfsKEhQiAAvgFCEQgRGqHFA+QCrAXCrAgQCdAeCjALQSzBXS1ASQBsABBtAKQN6BQNfjHQEghDEThkQB/gvBMhiQDlkplvibQpej/qNhAQgCAAgCgKIABgJIACgKQACgFADgEQADgFAFgEIAKgHQM+gHKUHWQBmBIgZB/QhGFYlwBhQo+CWpRBSQm2A+m1AAQkeAAkdgbg");
	this.shape_31.setTransform(9.1,214.8,1,1,-1.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#BF1853").s().p("APbbJQisg0izgSQjTgVjHhCQhOgahAg1QhjhSh/gNImzgrQitgSingtQiIgliPgPQi4gTichpQgjgXgxgDQkcgRhYj8Qg9gNg8gUQhoglhFhTIgHgIQg0g1gIhGQgEgigBgiQgCgcADgaQAMhbBdgQIA9gKQBIgOBDgbQB0gvA4hxQADgEgBgCQgDgFgHAAQgxgBgyAFQgDAAgCAEIgFAIQgJAQgNANQggAjgsAOQhUAahUgZQgXgHgUgQIgKgIQgXgXgSgaQgOgTgRgQQgFgEgFgBQgogKgsgBQhYgChUgcQg4gSg4gUQgXgJgGgYIgCgGQgCgFgEgEIgPgIQhKgnhQgbQg5gTgZg1IgKgWIgEgIQgOgigMgjQgKgegIgfQgFgTgHgTIgJgXIgEgIQgYgpAGgzQACgWAAgXQACgEACgDQAkgkAugXQBNglBIgvQAMgHAIgMIAGgHQAUgfAGglQAFglAUghQAMgTAOgSIAOgRIAJgGQBFgjBOgWIAEgIQAOghAcgSQBag9B5ADQAkAAAhgRIAIgGQAcgWAKghQANgpAogVQASgJAGgUIAIgGQATgLAVgEQBPgOBPAHQAbACAbAHQAkAJAmAAQAyABAxgFQADAAACgEQAHgaACgbQAFhIA/grIAKgIQBXhVBtg3QA+gfBEgJQBfgOBgAMQD3AeD2gdIAKgIIAQgOQALgIAMgHQARgJATgHIA/gYQAWgIATgEQC0ghCHBtQA6AuBGAHQDTAUDUgYQBLgIBDglQCRhQCsABIDKAEQA6A6BHAjQBkAwBzgSIAcgFQD3gzBkDCQATAlAdAcQBqBpClgxQC+g4CsBCQBhAlAoBhQAEAKgBAMQBZBBBxAKQAYACASAQQAJAHAJAEQCGA+BUB5QA3BPAVBeQAHAhgBAjQgCB8gxBxQgRAngUAnQgoBNg1BBQhhB5igALQjFAOjEATQgkADggAPIgEAIIgDAIIgCAHIgBAHIAAAIIAAAHIADAIQACAEAEADIAMAIIAPAIIAKAFIAIACIARAHQAGACAFAFIAHAHIAGAFQBQgJBEAkQBEAkAjBFQAGALADANIABAHQAHA8gYA0QgTApgqAYIgZAPQgbAQgcAKQiPA0iXAcIgsAIQghAGgbAUQgGAFgIACIAAAIIAAAIIAAAHIgBAIIgCAIIgCAHIADAHQAPASATAKQApAWAmAZQAbASAIAeQAEATADAUIgBAHIgQAnQgNAegWAYQgVAXgaAQIgSAOIgEAIIgBAPIAAAHIAAAIIACAPIADAXIAEAXIABAQIAAAPIAAAPQAAAMgBALIgCAHIgFAIQjLARhMCVQh3DrkcBpQgTAHgSASQhcBgiEAAQhAAAhJgWg");
	this.shape_32.setTransform(-2.2,-150.1,1,1,-1.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#BF1853").s().p("AhkCKQg0gggsgpQgdgZgBgkQAAgeAEgeIABgGIAHgGIAGgFIAEgBIAOgFIAKgDIAKgCIAIAAIANABQAEgBADgCIAVgRIASgNIAJgGIAQgLQAKgHAKgCIApgKIAagGQAUAAAUAEQAYAFAXAGQAZAHAaAFQAbAEAWARQAVAQAIAZIACAHIgBAFQgDAKgEAJIgGAMIgEAHQgGAMgMAHQgWALgWAJIhDAbIAAAGIAAAGIAAAGIAAAGIAAAGIAAAGIAAAHIAAAGIAAAGIgCAGIgCAGQgXAWgeAMQgbALgaAAQglAAghgVg");
	this.shape_33.setTransform(28.2,75.3,1,1,-1.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#BF1853").s().p("AhTEOQh5g8iWgJQgVgBgSgUQgPgQgIgUQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAAAgBgBIgsgJQgHgBgHgDIgNgFIgMgHIgLgHIgNgLIgSgTIgFgFIgBgHIgBgGIAAgGIAAgGIAAgGIAAgGIAAgGIAAgGIAAgGIAAgHIAAgGIABgFIABgGIADgGIAGgGIAKgGIANgHIAHgGIAAgGIgCgkQgDglAWgcQAvg6BFgaQBpgnBvgEQEQAAESgHQCLgDASB0QALBPgCBUQgBA1gKAyIgFAGIgGAEIgEACIgKACIgKACIgCAHIgFALIgFAHIgHAGIgGAGIgFAHIgJAMIgMASQgIANgKAMQgNANgOALQgDACgDAAQjmgJjPAsQgHACgIAAQgRAAgRgJg");
	this.shape_34.setTransform(-87.9,67.1,1,1,-1.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#BF1853").s().p("AD/EGQjqgDjfgsQhBgMg1gpIgEgBQhaAPhQgjQgYgKgQgUIgEgGQgKgSgEgUQgHgiAHggQAGgYAIgYIAFgFQAWgRAbgMQAagLAYgQIAkgaIADgFIAJgSQAKgYAPgVQAKgNAPgJQAHgCAGABQCTAdB+gxQAggMAdgEQA5AAA5AGQAXACAVANQATALARAOQAOAKAKANIAAABQCdgtA6BsIAFAMIADAFQAkAqArAiQAmAfgSAvQgTAxgWAvIADAGIADAHIAEAGIACAGIAAAGQgJAagZAOQgtAagzAMQg+AOhCAAIgJAAg");
	this.shape_35.setTransform(61.7,168.9,1,1,-1.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#BF1853").s().p("Aw/Q4Qg3gMg1gSQkPhfkegyQl4hBl7ACIAKAEIAOAFQAFACADAEIAEAFIADAGIABAHIABAGIgDAGQgNAagfgFQgmgFgmgIIg1gMIgbgGQgFgBgFgDQgkgRgZgiQgPgTgQgTIgCgGIAAgGIAAgGIgBgGIgBgGQgBgDgDgCQhdg1hngqQgcgLgNgZQgYgwgcguIgDgGQgTg5gigvIgUgZIgLgMQgmgsgMg3QgLgvAYgnIAEgEQAzgvBDgcQAQhBgEhGQgEhZBDg7QBIhABZgsQBpgzBHhfQApg2BHgKQCrgaCogeQDugsD1gSQAtgDArgTQDLhbCviGQBCgzBWgMQC8gbC9ACIAGgGQAVgXAXgVQAhgdAngSQAogSAqgOIALgEIAGgCQBMgLBJgPIAAgBQEWguDyBxQA8AcBFgPQCzgqC4AqQBVATBNAsQAXAOAcgEQDCgdCXBpQBPA4BigMQDOgaC1BOQBwAwA5BzQAHANAKANQADACACAAQDIgaCbBRQAjATAIAnQAGAcASAUQAZAdAiAUQAGAEAHABQCOAGCNAFIAHAGQAqAwA6ASQBtAhBwAXQAZAGAYAPQAoAaATAqIACAGQANAqAKArQAFAWABAWIgBAFQgVAngoAWQgCADAAAEQgCAPAAAPQAAATADASIADAfQABAPAGAPIADAHIAOA3IAJAlIACAGQADAQAEAPQAHAVABAWQABADgBADIgDAGQgHALgMAIIgSALQgQAJgFARIgGAYIgEASIgBATIAAAMIAAAGQABATgEASIgDAMIgIAHQgQATgXAHQheAghngCQgVAAgWADQhmC6jYgdQj6ghj2A4QnVBrncA8QiSASiLA1QhaAihcgbQjlhEjsAkQjlAijpAVQhNAHhOALQh/ASh9AAQi2AAi0glg");
	this.shape_36.setTransform(0.3,-226.2,1,1,-1.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#BF1853").s().p("AMQJvQjWg1jZAhQiTAWiVgNQmmglmjAbIi6ALQiEAIiDgRIlrguQg5gGgpgyQhih2hah4Qgpg3AChHQjMgIhuiZQgjgxgqgoQhkhehhheQhKhJAxhkQAeg9BOgEQHhgaHWBnQBwAYBxAUQDcAoDFBpQAnAVAuAAQCnABCiAtQBaAaBhABQG+AFGzgmQDNgSCihuQCThlDAACQBoAABag1QBJgrBQgLQDKgaDMgVQB5gMB0geQDQgbABCsQABBOgjBLQgtBggnBmQgeBPhVAjQhLAfgVBNQgqCbivAfQhIAMg3AxQg6ErlIgfQjwgWjoAyQg3AMg3AAQhAAAhBgQg");
	this.shape_37.setTransform(0.9,-89.6,1,1,-1.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#BF1853").s().p("Ag3A2QgOgNABgTIABgmIAAgFIgCgEIgEgGIgFgFIgBgEIgBgFIAAgFIAAgFIAAgFIACgFIAFgFIAHgEIALgDIAAgBQAuAAAsABIAMACIAGAFQAKAKAJALQAKAMgBAQQgCARAAARQAAATgLAQQgJANgMAKIgMAEQgQAEgOAAQgiAAgagZg");
	this.shape_38.setTransform(19.5,57.9,1,1,-1.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#BF1853").s().p("AglBjQhGgchQgCIgGgGIgNgOIgQgTQgIgKgFgLQgEgHgCgGQgEgLgFgJQgDgHABgHIABgFQACgJAIgHIAUgTIAVgSQALgJAMgGQAMgHAJgCQB9AAB7AEQA/ACAvAmQA0AqgBA6QAAAdgZATQgLAIgQACIgBAFIgCAEIgDAFIgHAEQg6AVg4AAQg5AAg2gWg");
	this.shape_39.setTransform(-89.5,62.6,1,1,-1.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#BF1853").s().p("AggBnQgwgMgrgRQgmgOgogKQgrgLgagmIgCgEIgBgKIgBgFIAAgFIAAgKIAAgEIAAgFIAAgFIAAgFIAAgFIABgFIABgKIACgFIAFgEQAQgLAUgDIAGgBIAXgFIAHgCIARgFIAHgDIADgBIAJgCQBjAFBjACQBGABBAAWQChA6hkBnQgNANgUAGQhCAThBAAQg0AAg0gMg");
	this.shape_40.setTransform(44.3,153.2,1,1,-1.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#BF1853").s().p("A5BNWQgcgdAUgnQAvhdBChOQA6hEADhdQAGisBRiXQAvhXgDhkIgBgDIgFgCQgKgCgIgDQgFgCgEgDIgGgGIgEgGIgCgGIgCgGIAAgHIAAgGIAAgGIAAgGIACgGQBIguBagCQGfgFF9iWQAagKAVgVIC3gIIAMgCQALgZAFgaQAMg5A1gdIDLhsQBFgkBEgnQAIgFAHgGQAFgMgFgMQgHgPgDgPQgFgWAAgWQAAggAVgXQApguA+gNQAXgEASgFQC+A/BkC5QARAiAuADQDFANCoBZQBhAzB2AVQByAUAmBvQAcBRAZBSQAkB3AHB/QAHCRhMBuQhFBkh7ATQkBApkKgOQhcgEhXAjQmkCpnCBHQjAAejDAWQgxAGgwAUQkHBrklggQgzgGgzAPQgtAMgoAAQhdAAhChFg");
	this.shape_41.setTransform(189.7,-215.9,1,1,-1.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#BF1853").s().p("AEfQdImyhmQh1gch6gOQhKgJhHgMQiTgXiXADIgCAGIgCAGIgCAGIgEAGIgIAHIgFADIgFADQgcAHgUgTQgRgRgXgKIgxgXQgVgLgSgQIgFgFQh0AQhjgyQgcgPgYgVIgUgTIhpAAQhbA8hsAYIgMACQl0AXlggaQgugEgpgRQhZglhdgfQhXgeg+hGQgtg1gkg8Qg/hsAfh7QAfh5CCgwQAOgTADgYQACgWAHgWQAFgRADgTIABgGQAAgPABgPQACgbgHgXIgDgGQgJgRgEgUQgEgSAAgTIgBgfQgBgZADgYQBRhXB4gVQAIgCAHABQCFAKBNhfQAqgzApg2QBOhkB9gWQBUgPBJgZQBBgWA6gnQBbg+BwATQA7AKAlAyQB6ATBkg9QBmg9B+AZQBAANBDgDQACAAACgDQA9hjB6gDIAQgCQCYgcCVAbQCxAgCygdQCdgbCfgEQAbgBAcgOQBvg4B9gJQAfgCAbgFQFoBOF1gOQApgBApASQBnAuB8AQQBtAPBjAgQCQAvCVglQCdgmCXAzQCIAvCEAXQCJAYgaCJQgQBShGA0QiDBfigAdQkZAzkShIQjjg9jsAqQlSA7lZgXQmBgZmCgWIjXgNQj6gQj6AVIiCALQkgAYkhAcQhTAHgiBDQF3DPG+gaQDhgMDcAgQEWAqEcgUICegLQB4gJB2AVQCcAdCYgpQDOg2AGC6QAECKhJB7QgpBEAFBTQAEBegRBbQgNBEgqA0QhUBriNAXQioAbiVBTQhPAshZAAQgrAAgugKg");
	this.shape_42.setTransform(-62.2,-218.4,1,1,-1.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#BF1853").s().p("AhxH8Qg3gXg+gBQktgFktgSQiMgJh4hMQhUg2hkgUQlmhIjokbQgwg7ABhPQAEi4CvhcQA7gfBCgCQDMgEDJARQC7APAgCtQAHAnAnAaQCiBrCTCEQCwAJCphDQA/gaBFgFQENgXEPAbQAPABATgKQELiRFDAHQDFAFg7iZQg9ihC4gjQBUAOBJAxQBNAzBbgtQBIgkBQgRQBvgYAoBYQAnBUhEArIgDATQgDAMgBAMQAAANgEAMQgMAfgbARIgWAOQgSALgQAOQgYAUgaAQIghATQgIEsk5BwQhVAehCA/Qg7A4hLgEQk0gQkUB2QiaBDiaAAQiVAAiUhAg");
	this.shape_43.setTransform(13.1,-88.5,1,1,-1.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#BF1853").s().p("AgLAOIgHgFIAAgDIAAgBIABgFIACgFIAEgFQACgCADgBIAEgCIAJABIAGABIADADIABACIABADIABACIgBAEQgCAGgFABQgHACgEAEQgDACgCAAQgDAAgDgCg");
	this.shape_44.setTransform(15.8,61.2,1,1,-1.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#BF1853").s().p("AgeAeIgWgNIgBgCIAAgDIAAgCIABgDIABgCIgCgDIgBgCIgCgCIgCgCIgBgDIAAgCIgBgFQAAgEACgEIAFgHIAEgDIAGgBIAEgBIAFgCIADgCIAEgBIAEgBIAAgBIAgABQAMABALADQAOAEAIAMQAHAMgBAOQAAALgDAKIgBABQgKAIgNADQgLADgKAAQgWAAgUgMg");
	this.shape_45.setTransform(37.7,148.7,1,1,-1.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#BF1853").s().p("AgbAYQgMgGAAgOIAAgTQAAgEABgDIACgDIADgCIAEgDIAEgCIABAAIAFgBIAAAAIAGABIAoADIAJADIABADIACACIABAIIAAAMQAAAGgCAGIgFANQgCAGgFADIgCAAIgEABIgHAAQgVAAgTgKgAgNgDIAAAGIABACIAGACIAFABQAGAAAFgDQADgBABgEIAAgBQgOgDgNAAg");
	this.shape_46.setTransform(15.8,61,1,1,-1.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#BF1853").s().p("AgQBGQgbgHgcgDQgFAAgEgCIgCgDQgCgFAAgFIAAgKIAAgIIAAgKIAAgMIABgMIgBgCIgDgDQgFgEABgGIABgKIgBgKQAAgHAEgGQAIgJAKgGQAEgDAEAAIBrABQAlABAHAjQAGAfgIAfQgIAggjALQgDABgDADIgDABIgPAAQgTAAgSgEg");
	this.shape_47.setTransform(-77.4,65.8,1,1,-1.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#BF1853").s().p("AnmBSQgEAAgEgDQgDgEgCgDQgGgPAFgPIAEgNIACgGQAHgNAOgDQAigHAigCQBOgIBOgFIABgGQADgKAEgJQAKgUAXgDIAKgBIAfgFQA4gHA2gPQANgEARABIAAgBQBRAABSADQAYABATAPQAKAGAHAKQAEACAEgBQB5gIBzAeIAPAEQAcAJANAZQAPAfgOAfQgJASgRAMIgOACIiwABQmAAAl/gOg");
	this.shape_48.setTransform(194.9,-187.4,1,1,-1.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#BF1853").s().p("AjBBrIgIgHIgGgGIgFgMQgDgJgBgKIgDgSQAAgKAEgIIANgTIAAgGIAAgFIABgNIACgMIAGgMIAIgNIALgMIAFgEIAFgCIAKgCQAZgCAagFIAAgEIADgFIAGgHQADgDAFgCIAOgEIAAgBQB+AACAACQAHAAAHACIAIAHIAEAFIADAGIADAHIADAGIACAGIABAGIgBAGIgCAGIgDAGIgFAHQgGAGgDAHIgEALIgEAMIgCAGIgGAGQgvAig3AMIi1AnQgnAIgnAAIgQAAg");
	this.shape_49.setTransform(281.5,-188.2,1,1,-1.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#BF1853").s().p("AF2EtQgqgIgdgdQgOgPgHgVQidgqiwAKQgkABgMgjQgJgegVgUQhbhbiLAjQiRAkhXhxIgCgHIgBgSIAAgMIAAgTIAAgSIABgTIgBgSIAAgNIAAgGIAAgGIgDgFQgCgEgFgDIgTgNIgKgGIgIgGIgIgGIgGgGIgCgHIgCgGIAAgGIAAgGIAAgGIAAgGIAAgHIAAgGIACgGQALgOARAAQA4gBA2gMQAfgHAhgDQASgBAOgDQAQAAARACQASACARAEQAUAGAOAQIAXAaIAZAYIAPAMQBPgJBMAaQAeAKATAbQAQAVAKAYIAHAMIADAGIAKANQB1gKBiBBQAXAPAaAIQCTAoCigUQBBgJAZBBQAHAPgCARIgCAGQgEAQgQAGIgoAOQgaAIgaAFIgzALIAAAGIAAAMIAAANIABAGIADAMQADAGAAAHIABAMIgBAMIgBAGQgFANgNAHQgjAVgpAAQgQAAgRgDg");
	this.shape_50.setTransform(268.5,-280.1,1,1,-1.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#BF1853").s().p("AqMDOIgIgHIgQgRQgHgJgFgLQgFgIgDgJQgEgOgNgGQgEgCgFAAQhAgBhBABIgGAHQggAigrAOIggAJIgIACQjfAqjEgsQgHgCgGgGIgGgHIgEgFQgEgMgBgNQgEg5AxgVIBugwQBGgcA8guQBDg0BRgiQBegnBZAZQBJAUBKgaQBSgeBXAGQCmAMCpglQB7AAB6AMQA4AEAzAcQAgARAjADQBFAHBGgBQADgDAEgBQCOg4CZAqQAcAHAbAEQB8ASB5ggQB4gfBxAhQBKAXBDAgQAkASACApQADA6gtAbIADAGIADAHIADAGIACAGIABAGIABAGIAAAGIAAAGIAAAHIAAAGIAAAGIAAAGIAAAGIgBAGIgCAGIgGANQgEADgEABQhdAQhegKQgqgFgogLQgWgFgXABIgEAGQgHAKgJAKQgKAKgOAFQgaALgbgCIgUgDIgLgDQgagIgWgTQgIgHgKgGQgPgLgNgOIgGgGIgFgEQgGgCgGgBQkigTkXgFQgtAAgrAGQiiAXilALQhWAHhRAdQhRAchSAXQgqANgrAAQghAAgjgIg");
	this.shape_51.setTransform(17.3,-299.1,1,1,-1.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#BF1853").s().p("ANTKxQl0gtmBAOQhFAChEgJQkwgmkthFQjug2iwikQgmgkAdg1QAfg2A/geQAVgLADgPQgfgPgjgIIhCgRIgjgIQhCgQAQhAQAbhtCGgOQBIgIAvgvQAjgjgQgyQgBgEgDgDQhCgghRAaQhBAWhCAOQhlAWhSgvQgjgTgWgkQgRgcgOgfQgagRgjgFQgngGgmgNQgYgHgZAAQibAGiQgyQhlgjgnhaQgLgZAEgbQApgmBAgBQBggBBdAUQCmAkCqAIQBCACA2ArQAqAhAkAmIAFAEIACABIBDgBIAFgGIAKgMIAMgNIAPgMIAVgUIAJgLIAHgMIAEgHIAEgGIAGgGIAGgGIAGgEIAHgCIC7gHIACgFQAFgHAGgFIAPgNQAJgHAGgHQALgLAOgDIAagFIAdgEIAOgBIAAgBQBzgLBqAkQBkAhBoAcQB6AhgZB9QgSBXhtABQhxAChbBHIgBAGIgBASIgBAMQgDANgFAMIgIASIgDAHIgEAGIgJAMIgGAGIgKAHIgTAMIgdAUIgOALQgCADAAADIgCAMIAAANIAAAGIAAASIAAANIAAAMIAAAGIAAAGIAAAHIAAAGIAAAGIAAAGIgBAGIgFAMIgCAGQB9gSBsBdQAuAoA5gGQCogSCZA1QAxARAvAZQBgAyBvALQAzAGA1AKQCPAeCPgYQANggAhgOQAmgPApgIQC5giC9AdQCEATBrhNIADgGIAGgSQACgKAHgJIAUgXQAHgJAGgLIACgGIAGgMIAHgNQAFgKAKgHQAagSAegOIALgFIADgHIADgGIACgGIAEgGIACgGIACgGIAAgGQgshHhKgwQh7hSAMiWQAMiLCegUQD9ghD3A1QAWAFgDAcQgOCnjPgMQg/gEgSAvQABAkAyAQQAeAKATAcQARAbAJAfQATBBgDBGQgBA1gHA0QgGAoANAlQAeBWhdAkQgmAPgqAHQDJDTkfBnQkpBrkzAAQhrAAhrgNg");
	this.shape_52.setTransform(-32.8,-109.7,1,1,-1.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#BF1853").s().p("AhbLqQjlgNjWhkQg9gcg9gkQhCgngjhEQgyhfgJhtQgFhFAAhFIgBgnQgBguAEgtQARgVATgSQBshjBIiAQBIh/CigBQBCAAAxg0QCMiaDlAQQAvADAoghQAtglAwggQAqgcArgJQD2g7CUCrQB8CQjBA2QjUA7h5DKQgQAcgkAJImdBqQi9AviACPIAAAIIAAAHIAAAIIAAAIIAAAIIAAAHIAAAIIAAAIIAAAHIAGAHQA2AtA+AgQBOApALBOQAHA1AhAnQAYAdAkASQA8AfAGA+QADArgmAXQgKACgJAAIgEAAg");
	this.shape_53.setTransform(-248.6,-239.5,1,1,-1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_24},{t:this.shape_23}]},1).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25}]},1).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29}]},1).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41}]},1).to({state:[{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41}]},1).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48}]},1).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48}]},1).to({state:[]},1).to({state:[]},71).wait(6));

	// bounds
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(64,64,69,0)").s().p("Eg5WA3LMAAAhuVMBytAAAMAAABuVg");
	this.shape_54.setTransform(-5,13);

	this.timeline.addTween(cjs.Tween.get(this.shape_54).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-372.1,-340,734.2,706.2);


// stage content:
(lib.Untitled1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Explosion("synched",99);
	this.instance.parent = this;
	this.instance.setTransform(648.4,398.5,1,1,0,0,0,-5,13);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(31).to({startPosition:99},0).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(953.3,430.5,734.2,706.2);
// library properties:
lib.properties = {
	id: 'BEF90AF371AB478E9F065E16B00B1A40',
	width: 1344,
	height: 770,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BEF90AF371AB478E9F065E16B00B1A40'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;